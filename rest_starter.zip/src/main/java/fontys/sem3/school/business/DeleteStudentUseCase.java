package fontys.sem3.school.business;

public interface DeleteStudentUseCase {
    void deleteStudent(long studentId);
}

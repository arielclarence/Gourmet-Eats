package fontys.sem3.school.business;

import fontys.sem3.school.domain.GetCountriesResponse;

public interface GetCountriesUseCase {
    GetCountriesResponse getCountries();
}

package fontys.sem3.school.business;

import fontys.sem3.school.domain.UpdateStudentRequest;

public interface UpdateStudentUseCase {
    void updateStudent(UpdateStudentRequest request);
}
